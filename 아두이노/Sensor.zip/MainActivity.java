package com.example.choikt.sensortest;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    SensorManager sensorMgr = null;
    TextView msg1 = null;
    TextView msg2 = null;
    TextView msg3 = null;
    TextView msg4 = null;
    TextView msg5 = null;
    TextView msg6 = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        msg1 = (TextView)findViewById(R.id.textView1);
        msg2 = (TextView)findViewById(R.id.textView2);
        msg3= (TextView)findViewById(R.id.textView3);
        msg4 = (TextView)findViewById(R.id.textView4);
        msg5 = (TextView)findViewById(R.id.textView5);
        msg6 = (TextView)findViewById(R.id.textView6);

        sensorMgr = (SensorManager)getSystemService(Context.SENSOR_SERVICE);


        // 가속도 센서 이벤트를 시작
        Sensor sensorAcceler = sensorMgr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if( sensorAcceler != null )
            sensorMgr.registerListener(this, sensorAcceler, SensorManager.SENSOR_DELAY_UI);

        // 자기장 센서 이벤트를 시작
        Sensor sensorMagnetic = sensorMgr.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if( sensorMagnetic != null )
            sensorMgr.registerListener(this, sensorMagnetic, SensorManager.SENSOR_DELAY_UI);

        // 방향 센서 이벤트를 시작
        Sensor sensorOrientation = sensorMgr.getDefaultSensor(Sensor.TYPE_ORIENTATION);
        if( sensorOrientation != null )
            sensorMgr.registerListener(this, sensorOrientation, SensorManager.SENSOR_DELAY_UI);

        // 밝기 센서 이벤트를 시작
        Sensor sensorLight = sensorMgr.getDefaultSensor(Sensor.TYPE_LIGHT);
        if( sensorLight != null )
            sensorMgr.registerListener(this, sensorLight, SensorManager.SENSOR_DELAY_UI);

        // 근접 센서 이벤트를 시작
        Sensor sensorProximity = sensorMgr.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        if( sensorProximity != null )
            sensorMgr.registerListener(this, sensorProximity, SensorManager.SENSOR_DELAY_UI);


    }


    private long lastTime;
    private float speed;
    private float lastX;
    private float lastY;
    private float lastZ;
    private float x, y, z;
    private static final int SHAKE_THRESHOLD = 800;
    int count = 0;

    @Override
    public void onSensorChanged(SensorEvent event) {
        String strMsg = "";
        float v[] = event.values;



        switch( event.sensor.getType() ) {
            // 가속도 센서 이벤트 일때 X,Y,Z 축 값을 화면에 표시
            case Sensor.TYPE_ACCELEROMETER :
                strMsg = "Acceler - X: " + cut2(v[0]) + " / Y: " + cut2(v[1]) + " / Z: " + cut2(v[2]);
                msg1.setText(strMsg);

                long currentTime = System.currentTimeMillis();
                long gabOfTime = (currentTime - lastTime);
                if (gabOfTime > 100) {
                    lastTime = currentTime;
                    x = event.values[0];
                    y = event.values[1];
                    z = event.values[2];

                    speed = Math.abs(x + y + z - lastX - lastY - lastZ) / gabOfTime * 10000;

                    if (speed > SHAKE_THRESHOLD) {
                        count++;
                        msg6.setText("shake = " + count);
                    }

                    lastX = event.values[0];
                    lastY = event.values[1];
                    lastZ = event.values[2];
                }



                break;
            // 자기장 센서 이벤트 일때 X,Y,Z 축 값을 화면에 표시
            case Sensor.TYPE_MAGNETIC_FIELD :
                strMsg = "Magnetic - X: " + cut2(v[0]) + " / Y: " + cut2(v[1]) + " / Z: " + cut2(v[2]);
                msg2.setText(strMsg);
                break;
            // 밝기 센서 이벤트 일때 X,Y,Z 축 값을 화면에 표시
            case Sensor.TYPE_ORIENTATION :
                strMsg = "Orientation : " + cut2(v[0]) + " / Y: " + cut2(v[1]) + " / Z: " + cut2(v[2]);
                msg3.setText(strMsg);
                break;
            // 밝기 센서 이벤트 일때 X,Y,Z 축 값을 화면에 표시
            case Sensor.TYPE_LIGHT :
                strMsg = "Light : " + cut2(v[0]);
                msg4.setText(strMsg);
                break;
            case Sensor.TYPE_PROXIMITY :
                strMsg = "Distance : " + cut2(v[0]);
                msg5.setText(strMsg);
                break;

        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public double cut2(double orig) {
        double d = Double.parseDouble(String.format("%.2f", orig));
        return d;
    }


    @Override
    public void onStop() {
        super.onStop();
        if (sensorMgr != null)
            sensorMgr.unregisterListener(this);
    }
}
