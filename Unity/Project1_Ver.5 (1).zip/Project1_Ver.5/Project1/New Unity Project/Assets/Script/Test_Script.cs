﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test_Script : MonoBehaviour {

	LineRenderer lineRenderer;
	public Vector3 PrevPoint;
	public Vector3 Dot = Vector3.zero;
	public int layermask;
	public int count;
	public RaycastHit hit;

	private void Start(){
		lineRenderer = GetComponent<LineRenderer> ();
		//lineRenderer.SetColors (Color.red, Color.yellow);
		//lineRenderer.SetWidth (0.1f, 0.1f);
	}
	int i;
	void Update(){

		lineRenderer.SetPosition (0, this.transform.position);
		layermask = (-1) - (1 << LayerMask.NameToLayer ("Cannot"));
		//layermask = ~layermask;
		Debug.Log (layermask);
		PrevPoint = this.transform.position;
		if (Physics.Raycast (this.transform.position, this.transform.forward, out hit, 50f, layermask)) {
			count = 1;
			Debug.Log (hit.collider.transform.name);
			if (hit.collider.transform.tag == "reflash") {
				for (i = 0; i < 4; i++) {
					if (hit.collider.transform.tag == "reflash") {

						lineRenderer.SetPosition (count, hit.point);
						Debug.Log (hit.collider.transform.name);
						count++;

						Dot = hit.point - PrevPoint;
						if (Dot.x < 1 && Dot.x > -1)
							Dot.x = 0;
						if (Dot.y < 1 && Dot.y > -1)
							Dot.y = 0;
						if (Dot.z < 1 && Dot.z > -1)
							Dot.z = 0;

						if (Dot.x > 0)
							Dot.x = 1;
						else if (Dot.x < 0)
							Dot.x = -1;

						if (Dot.y > 0)
							Dot.y = 1;
						else if (Dot.y < 0)
							Dot.y = -1;

						if (Dot.z > 0)
							Dot.z = 1;
						else if (Dot.z < 0)
							Dot.z = -1;

						PrevPoint = hit.point;
						Debug.Log (count + " - Pos:" + Dot + "Hit:" + hit.collider.transform.parent.transform.forward);
						if (hit.collider.transform.parent.transform.forward == Dot)
							Physics.Raycast (hit.point, hit.collider.transform.parent.transform.up * -1, out hit, 50f, layermask);
						else if (hit.collider.transform.parent.transform.forward * (-1) == Dot)
							Physics.Raycast (hit.point, hit.collider.transform.parent.transform.up, out hit, 50f, layermask);
						else if (hit.collider.transform.parent.transform.up == Dot)
							Physics.Raycast (hit.point, hit.collider.transform.parent.transform.forward * (-1), out hit, 50f, layermask);
						else if (hit.collider.transform.parent.transform.up * (-1) == Dot)
							Physics.Raycast (hit.point, hit.collider.transform.parent.transform.forward , out hit, 50f, layermask);
					}
				}

				for (i = count; i < 5; i++) {
					Debug.Log (count + " - Pos:" + Dot + "Hit:" + hit.collider.transform.parent.transform.forward);
					lineRenderer.SetPosition (i, hit.point);
				}
			} 
			else {
				int i;
				lineRenderer.SetPosition (count, hit.point);
				for (i = count; i < 5; i++) {
					Debug.Log (count + " - Pos:" + Dot + "Hit:" + hit.collider.transform.parent.transform.forward);
					lineRenderer.SetPosition (i, hit.point);
				}
			}
		}

	}
}