﻿using UnityEngine;
using System.Collections;

public class MoveCube_Script : MonoBehaviour {

	public static bool CubeCheck;
	public Vector3 dot = Vector3.zero;
	public float angle = 0;
	public MoveScript ForCheckGravity;
	public test2 test2;
	public float CubeSpeed;
	public float DistanceForCube;
	public RaycastHit hit;

	// Use this for initialization
	void Start () {
		CubeCheck = false;
		test2 = GetComponentInChildren<test2> ();
		CubeSpeed = 4f;
	}
	// Update is called once per frame
	void Update () {

		if(Physics.Raycast(transform.position,transform.forward,out hit, 50f)){
			
			if (hit.transform.tag == "Ladder") {
				if (hit.distance <= 1.0f)
					MoveScript.NormalCheck = 1;
				else
					MoveScript.NormalCheck = 0;
			} 
			else {
				MoveScript.NormalCheck = 0;
			}

			if (hit.transform.tag == "Cube") {
				if(Input.GetKey(KeyCode.G)){
					if (hit.transform.gameObject.GetComponent<ForCube> ().FreezeCheck == false) {
						RaycastHit hit_cube;
						if(Physics.Raycast(hit.transform.position,this.transform.GetComponentInParent<MoveScript>().transform.up * -1, out hit_cube, 50f)){
							if (hit_cube.transform.tag == "ground")
								hit.transform.GetComponent<ForCube> ().FreezeCheck = true;
						}
					}
					else
						hit.transform.GetComponent<ForCube> ().FreezeCheck = false;
				}

				DistanceForCube = Vector3.Distance (hit.transform.position, transform.position);
				//Debug.Log ("distance:" + DistanceForCube);
				dot = hit.transform.position - transform.position;
				switch(ForCheckGravity.check){
				case 0:
					angle = Mathf.Atan2 (dot.x, dot.z) * Mathf.Rad2Deg;
					break;
				case 1:
					angle = Mathf.Atan2 (dot.x, dot.y) * Mathf.Rad2Deg;
					break;
				case 2:
					angle = Mathf.Atan2 (dot.z, dot.y) * Mathf.Rad2Deg;
					break;
				case 3:
					angle = Mathf.Atan2 (dot.x, dot.z) * Mathf.Rad2Deg;
					break;
				case 4:
					angle = Mathf.Atan2 (dot.x, dot.y) * Mathf.Rad2Deg;
					break;
				case 5:
					angle = Mathf.Atan2 (dot.z, dot.y) * Mathf.Rad2Deg;
					break;
				}
			}
		}
	}
}
