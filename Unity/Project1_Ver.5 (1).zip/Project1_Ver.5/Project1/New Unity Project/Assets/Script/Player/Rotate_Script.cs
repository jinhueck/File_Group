﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate_Script : MonoBehaviour {

	public MoveScript ForMoveScript;

	public float ySpeed = 100.0f;

	//private float x;
	private float y;

	public float yMinLimit = -10;
	public float yMaxLimit = 40;

	void Start () {
		Vector3 angles = transform.eulerAngles;
		//x = angles.y;
		y = angles.x;
	}

	void Update () {
		y -= Input.GetAxis ("Mouse Y") * ySpeed * 0.02f;

		y = Mathf.Clamp (y, yMinLimit, yMaxLimit);
		Quaternion rotation;
		rotation = Quaternion.Euler (y, 0, 0);
		transform.localRotation = rotation;
	}
}