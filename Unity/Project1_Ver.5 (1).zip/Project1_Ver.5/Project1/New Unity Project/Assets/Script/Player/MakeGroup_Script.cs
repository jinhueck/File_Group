﻿using UnityEngine;
using System.Collections;

public class MakeGroup_Script : MonoBehaviour {

	public Transform Parent;
	public Transform Child;
	public Transform Save_Parent;
	public Transform Save_Child;
	public bool parentcheck;
	public bool childcheck;
    public int layermask;
	public MoveScript ForCheckGravity;

	void Start () {
		Parent = null;
		Child = null;

		parentcheck = false;
		childcheck = false;
        layermask = (-1) - (1 << LayerMask.NameToLayer("Player"));
    }

	void Update () {
		RaycastHit hit;

		if (Physics.Raycast (transform.position, transform.forward, out hit, 100f,layermask)) {
			if (Input.GetMouseButtonDown (0)) {
				Parent = hit.transform;
				parentcheck = true;
			}
			if (Input.GetMouseButtonDown (1)) {
				Child = hit.transform;
				childcheck = true;
			}
		}
		if (parentcheck == true && childcheck == true) {
			float DistanceForGroup = Vector3.Distance (Parent.transform.position, Child.transform.position);
            if (Child.tag == "Cube" && Parent.tag == "Cube")
            {
                if (DistanceForGroup <= 2.3f) {
				
					//Child.gameObject.GetComponent<Parent_Child_Script> ().PlayerCheck = true;
					//Child.gameObject.transform.parent = Parent.gameObject.transform;

					StartCoroutine (Make ());
                    Parent = null;
                    Child = null;
				}
                else
                {
                    Debug.Log("Too Far Between Objects");
                }
            } 
			else {
				Debug.Log ("That's not cube");
			}
			parentcheck = childcheck = false;
		}
	}
	IEnumerator Make(){
		Save_Parent = Parent;
		Save_Child = Child;
		Save_Child.gameObject.GetComponent<Parent_Child_Script> ().PlayerCheck = true;
		Save_Child.gameObject.transform.parent = Save_Parent.gameObject.transform;
		yield return new WaitForSeconds(4f);
		switch(ForCheckGravity.check){
		case 0:
			Save_Child.position = Save_Child.position + new Vector3 (0, 1f, 0);
			break;
		case 1:
			Save_Child.position = Save_Child.position + new Vector3 (0, 0, -1f);
			break;
		case 2:
			Save_Child.position = Save_Child.position + new Vector3 (1f, 0, 0);
			break;
		case 3:
			Save_Child.position = Save_Child.position + new Vector3 (0, -1f, 0);
			break;
		case 4:
			Save_Child.position = Save_Child.position + new Vector3 (0, 0, 1f);
			break;
		case 5:
			Save_Child.position = Save_Child.position + new Vector3 (-1f, 0, 0);
			break;

		}

		Save_Child.gameObject.GetComponent<Parent_Child_Script> ().PlayerCheck = false;

		Save_Child.gameObject.transform.parent = null;
	}
}
