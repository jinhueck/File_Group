﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Change_Gravity_Script : MonoBehaviour {
	public MoveScript ForMoveScript;
	public bool check = false;
	public Canvas canvas;
	public test2 ForAngle;
	public GameObject Gravity_Pos_UI;
	Quaternion target;

	public int ForGravityCheck;
	void Start () {
		ForGravityCheck = 0;
	}

	void Update () {
		RaycastHit hit;
		if (Physics.Raycast (this.transform.position, this.transform.forward, out hit, 50f)) {
			switch (hit.transform.name) {
			case "Up":
				ForGravityCheck = 1;
				break;
			case "Side_1":
				ForGravityCheck = 2;
				break;
			case "Side_2":
				ForGravityCheck = 3;
				break;
			case "Side_3":
				ForGravityCheck = 4;
				break;
			case "Side_4":
				ForGravityCheck = 5;
				break;
			case "Down":
				ForGravityCheck = 6;
				break;
			default:
				ForGravityCheck = 0;
				Gravity_Pos_UI.SetActive (false);
				break;
			}
			//Debug.Log(ForMoveScript.check + " , " + ForGravityCheck + " , " + ForAngle.angle);
			//Debug.Log (hit.transform.name);
			//Debug.Log ("angle" + ForAngle.angle);
			if (ForGravityCheck != 0) {
				Gravity_Pos_UI.SetActive (true);
				//Debug.Log (ForMoveScript.check);

				//Debug.Log ("Object" + ForGravityCheck);
				switch (ForMoveScript.check) {

				case 0:
					
					switch (ForGravityCheck) {
					case 1:
						switch (ForAngle.angle) {
						case 1:
							target = Quaternion.Euler (new Vector3 (90, 90, 0));
							For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 5);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (90, 180, 0));
							For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 4);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (90, 270, 0));
							For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 2);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (90, 360, 0));
							For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 1);
							break;
						}

						break;
					case 2:
						target = Quaternion.Euler (new Vector3 (0, 90, 0));
						For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 5);
						break;
					case 3:
						target = Quaternion.Euler (new Vector3 (0, 180, 0));
						For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 4);
						break;
					case 4:
						target = Quaternion.Euler (new Vector3 (0, 270, 0));
						For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 2);
						break;
					case 5:
						target = Quaternion.Euler (new Vector3 (0, 360, 0));
						For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 1);
						break;
					case 6:
						switch(ForAngle.angle){
						case 1:
							target = Quaternion.Euler (new Vector3 (270, 270, 0));
							For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 3);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (270, 0, 0));
							For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 3);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (270, 90, 0));
							For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 3);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (270, 180, 0));
							For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 3);
							break;
						}
						break;
					}
					break;

				case 1:
					switch (ForGravityCheck) {
					case 5:
						switch (ForAngle.angle) {
						case 1:
							Debug.Log ("Sucesss2");
							target = Quaternion.Euler (new Vector3 (0, 0, 270));
							For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 5);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (90, -180, 0));
							For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 0);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (0, 0, 90));
							For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 2);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (0, 0, 0));
							For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 3);
							break;
						}

						break;
					case 6:
						target = Quaternion.Euler (new Vector3 (270, 0, 0));
						For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 3);
						break;
					case 3:
						//buttom
						switch (ForAngle.angle) {
						case 1:
							Debug.Log ("Sucesss2");
							target = Quaternion.Euler (new Vector3 (180, 0, 270));
							For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 5);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (180, 0, 0));
							For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 3);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (180, 0, 90));
							For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 2);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (180, 0, 180));
							For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 0);
							break;
						}
						break;
					case 1:
						target = Quaternion.Euler (new Vector3 (90, 0, 180));
						For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 0);
						break;
					case 4:
						target = Quaternion.Euler (new Vector3 (180, 90, 270));
						For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 2);
						break;
					case 2:
						target = Quaternion.Euler (new Vector3 (0, 90, 270));
						For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 5);
						break;
					}
					break;
				case 2:
					switch (ForGravityCheck) {
					case 1:
						target = Quaternion.Euler (new Vector3 (90, 90, 0));
						For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 0);
						break;
					case 2:
						//Buttom
						switch (ForAngle.angle) {
						case 1:
							Debug.Log ("Sucesss2");
							target = Quaternion.Euler (new Vector3 (0, 90, 180));
							For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 5);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (180, 270, 90));
							For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 5);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (0, 90, 0));
							For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 5);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (0, 90, 90));
							For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 5);
							break;
						}
						break;
					case 3:
						target = Quaternion.Euler (new Vector3 (180, 0, 270));
						For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 4);
						break;
					case 4:
						switch (ForAngle.angle) {
						case 1:
							Debug.Log ("Sucesss2");
							target = Quaternion.Euler (new Vector3 (0, 270, 180));
							For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 0);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (0, 270, 90));
							For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 4);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (0, 270, 0));
							For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 3);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (0, 270, 270));
							For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 1);
							break;
						}
						break;
					case 5:
						target = Quaternion.Euler (new Vector3 (0, 0, 270));
						For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 1);
						break;
					case 6:
						target = Quaternion.Euler (new Vector3 (270, 0, 270));
						For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 3);
						break;
					}
					break;
				case 3:
					switch (ForGravityCheck) {
					case 1:
						//buttom
						switch (ForAngle.angle) {
						case 1:
							target = Quaternion.Euler (new Vector3 (90, 90, 0));
							For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 0);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (90, 360, 0));
							For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 0);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (90, 270, 0));
							For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 0);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (90, 180, 0));
							For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 0);
							break;
						}

						break;
					case 2:
						target = Quaternion.Euler (new Vector3 (0, 90, 180));
						For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 5);
						break;
					case 3:
						target = Quaternion.Euler (new Vector3 (0, 180, 180));
						For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 4);
						break;
					case 4:
						target = Quaternion.Euler (new Vector3 (0, 270, 180));
						For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 2);
						break;
					case 5:
						target = Quaternion.Euler (new Vector3 (0, 360, 180));
						For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 1);
						break;
					case 6:
						switch(ForAngle.angle){
						case 1:
							target = Quaternion.Euler (new Vector3 (270, 90, 180));
							For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 5);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (270, 180, 0));
							For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 4);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (270, 270, 180));
							For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 2);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (270, 360, 0));
							For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 1);
							break;
						}
						break;
					}
					break;
				case 4:
					switch (ForGravityCheck) {
					case 5:
						//buttom
						switch (ForAngle.angle) {
						case 1:
							Debug.Log ("Sucesss2");
							target = Quaternion.Euler (new Vector3 (0, 0, 270));
							For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 1);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (0, 0, 0));
							For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 1);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (0, 0, 90));
							For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 1);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (0, 0, 180));
							For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 1);
							break;
						}
						break;
					case 6:
						target = Quaternion.Euler (new Vector3 (270, 0, 180));
						For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 3);
						break;
					case 3:
						switch (ForAngle.angle) {
						case 1:
							Debug.Log ("Sucesss2");
							target = Quaternion.Euler (new Vector3 (180, 0, 270));
							For_Gravity_UI (target, new Vector3 (2, 0, 0), hit, 5);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (180, 0, 180));
							For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 3);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (180, 0, 90));
							For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 2);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (180, 0, 0));
							For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 0);
							break;
						}
						break;
					case 1:
						target = Quaternion.Euler (new Vector3 (90, 0, 0));
						For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 0);
						break;
					case 4:
						target = Quaternion.Euler (new Vector3 (180, 90, 90));
						For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 2);
						break;
					case 2:
						target = Quaternion.Euler (new Vector3 (0, 90, 90));
						For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 5);
						break;
					}
					break;
				case 5:
					switch (ForGravityCheck) {
					case 1:
						target = Quaternion.Euler (new Vector3 (90, 0, 90));
						For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 0);
						break;
					case 2:
						switch (ForAngle.angle) {
						case 1:
							Debug.Log ("Sucesss2");
							target = Quaternion.Euler (new Vector3 (0, 90, 0));
							For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 3);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (180, 270, 90));
							For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 4);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (180, 270, 0));
							For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 0);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (0, 90, 90));
							For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 1);
							break;
						}
						break;
					case 3:
						target = Quaternion.Euler (new Vector3 (-180, 0, 90));
						For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 4);
						break;
					case 4:
						//buttom
						switch (ForAngle.angle) {
						case 1:
							Debug.Log ("Sucesss2");
							target = Quaternion.Euler (new Vector3 (0, 270, 360));
							For_Gravity_UI (target, new Vector3 (0, 2, 0), hit, 2);
							break;
						case 2:
							target = Quaternion.Euler (new Vector3 (0, 270, 90));
							For_Gravity_UI (target, new Vector3 (0, 0, -2), hit, 2);
							break;
						case 3:
							target = Quaternion.Euler (new Vector3 (0, 270, 180));
							For_Gravity_UI (target, new Vector3 (0, -2, 0), hit, 2);
							break;
						case 4:
							target = Quaternion.Euler (new Vector3 (0, 270, 270));
							For_Gravity_UI (target, new Vector3 (0, 0, 2), hit, 2);
							break;
						}
						break;
					case 5:
						target = Quaternion.Euler (new Vector3 (0, 0, 90));
						For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 1);
						break;
					case 6:
						target = Quaternion.Euler (new Vector3 (-90, 0, 90));
						For_Gravity_UI (target, new Vector3 (-2, 0, 0), hit, 3);
						break;
					}
					break;
				}
			}
		}
	}
	void For_Gravity_UI(Quaternion target, Vector3 UI_Pos, RaycastHit hit, int i){
		Gravity_Pos_UI.transform.rotation = target;
		Gravity_Pos_UI.transform.position = hit.transform.position + UI_Pos;
		if (Input.GetKey (KeyCode.E)) {
			ForMoveScript.check = i;
		}
	}
}
