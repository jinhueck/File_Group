﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenDoor_Script : MonoBehaviour {

	void Start () {

	}

}
