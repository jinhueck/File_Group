﻿using UnityEngine;
using System.Collections;

public class Parent_Child_Script : MonoBehaviour {
	public bool parentcheck = false;
	public bool PlayerCheck = false;
	public bool PlayerCheck_Child = false;
	private Transform newvec;
	public int num;
	Rigidbody rigid;
	public Transform Final_Parent;
	public MoveScript ForCheckGravity;
	public MoveCube_Script ForMoveCube;
	float CubeSpeed = 4f;
	float angle = 0; 
	float DistanceForCube;

	void Start () {
		num = 0;
		rigid = this.GetComponent<Rigidbody> ();
		Final_Parent = this.GetComponent<Transform> ();
	}
	
	// Update is called once per frame
	void Update () {
		RaycastHit hit = ForMoveCube.hit;
		angle = ForMoveCube.angle;
		DistanceForCube = ForMoveCube.DistanceForCube;

		if (PlayerCheck == true) {
			this.rigid.isKinematic = true;	
		} 
		else {
			this.rigid.isKinematic = false;	
		}

		while(Final_Parent.parent != null && Final_Parent.parent.tag == "Cube"){
			Final_Parent = Final_Parent.parent;
		}
		if (hit.transform != null) {
			if (hit.transform.tag == "Cube" && hit.transform == this.transform) {
				if (Input.GetKey (KeyCode.F) && DistanceForCube <= 2.0f) {
					if (Input.GetKey (KeyCode.S)) {
						MoveCube_Script.CubeCheck = true;
					} else {
						MoveCube_Script.CubeCheck = false;
					}
					switch (ForCheckGravity.check) {
					case 0:
						if (angle < 45 && angle > -45) {
							if (Input.GetKey (KeyCode.W)) {
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, ForCheckGravity.speed / 4);
							}
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -CubeSpeed);
						} else if (angle < -45 && angle > -135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (-ForCheckGravity.speed / 4, 0, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (CubeSpeed, 0, 0);
						} else if (angle < -135 || angle > 135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -ForCheckGravity.speed / 4);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, CubeSpeed);
						} else if (angle < 135 && angle > 45) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (ForCheckGravity.speed / 4, 0, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (-CubeSpeed, 0, 0);
						}
						break;
					case 1:
						if (angle < 45 && angle > -45) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, ForCheckGravity.speed / 4, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -CubeSpeed);
						} else if (angle < -45 && angle > -135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (-ForCheckGravity.speed / 4, 0, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (CubeSpeed, 0, 0);
						} else if (angle < -135 || angle > 135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, -ForCheckGravity.speed / 4, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, CubeSpeed, 0);
						} else if (angle < 135 && angle > 45) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (ForCheckGravity.speed / 4, 0, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (-CubeSpeed, 0, 0);
						}
						break;
					case 2:
						if (angle < 45 && angle > -45) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, ForCheckGravity.speed / 4, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -CubeSpeed);
						} else if (angle < -45 && angle > -135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -ForCheckGravity.speed / 4);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, CubeSpeed);
						} else if (angle < -135 || angle > 135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, -ForCheckGravity.speed / 4, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, CubeSpeed, 0);
						} else if (angle < 135 && angle > 45) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, ForCheckGravity.speed / 4);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -CubeSpeed);
						}
						break;
					case 3:
						if (angle < 45 && angle > -45) {
							if (Input.GetKey (KeyCode.W)) {
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, ForCheckGravity.speed / 4);
							}
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -CubeSpeed);
						} else if (angle < -45 && angle > -135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (-ForCheckGravity.speed / 4, 0, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (CubeSpeed, 0, 0);
						} else if (angle < -135 || angle > 135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -ForCheckGravity.speed / 4);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, CubeSpeed);
						} else if (angle < 135 && angle > 45) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (ForCheckGravity.speed / 4, 0, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (-CubeSpeed, 0, 0);
						}
						break;
					case 4:
						if (angle < 45 && angle > -45) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, ForCheckGravity.speed / 4, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -CubeSpeed);
						} else if (angle < -45 && angle > -135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (-ForCheckGravity.speed / 4, 0, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (CubeSpeed, 0, 0);
						} else if (angle < -135 || angle > 135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, -ForCheckGravity.speed / 4, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, CubeSpeed, 0);
						} else if (angle < 135 && angle > 45) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (ForCheckGravity.speed / 4, 0, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (-CubeSpeed, 0, 0);
						}
						break;
					case 5:
						if (angle < 45 && angle > -45) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, ForCheckGravity.speed / 4, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -CubeSpeed);
						} else if (angle < -45 && angle > -135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -ForCheckGravity.speed / 4);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, CubeSpeed);
						} else if (angle < -135 || angle > 135) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, -ForCheckGravity.speed / 4, 0);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, CubeSpeed, 0);
						} else if (angle < 135 && angle > 45) {
							if (Input.GetKey (KeyCode.W))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, ForCheckGravity.speed / 4);
							if (Input.GetKey (KeyCode.S))
								Final_Parent.GetComponent<Parent_Child_Script> ().rigid.velocity = new Vector3 (0, 0, -CubeSpeed);
						}
						break;
					}
				} else {
					MoveCube_Script.CubeCheck = false;
				}
			}
		}
	}
}
