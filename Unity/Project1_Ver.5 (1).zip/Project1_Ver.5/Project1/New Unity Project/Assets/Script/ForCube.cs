﻿
using UnityEngine;
using System.Collections;

public class ForCube : MonoBehaviour {
	public bool FreezeCheck;
	Rigidbody rigid;
	// Use this for initialization
	void Start () {
		rigid = GetComponent<Rigidbody> ();
		FreezeCheck = false;
	}
	
	// Update is called once per frame
	void Update () {
		StartCoroutine (Freeze ());
	}
	IEnumerator Freeze(){
		if (FreezeCheck == false) {
			rigid.constraints = RigidbodyConstraints.None;
			rigid.constraints = RigidbodyConstraints.FreezeRotation;
		} 
		else {
			rigid.constraints = RigidbodyConstraints.FreezeAll;
			yield return new WaitForSeconds (4f);
			FreezeCheck = false;
		}
	}
}
