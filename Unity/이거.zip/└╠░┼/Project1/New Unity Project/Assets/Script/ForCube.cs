﻿
using UnityEngine;
using System.Collections;

public class ForCube : MonoBehaviour {
	public bool FreezeCheck;
	public Rigidbody rigid;
	bool Freeze_Own;

	Transform Final_Parent;
	// Use this for initialization
	void Start () {
		rigid = GetComponent<Rigidbody> ();
		FreezeCheck = false;
		Freeze_Own = false;
		Final_Parent = this.GetComponent<Transform> ();
	}
	
	// Update is called once per frame
	void Update () {
		Final_Parent = this.transform;
		if(FreezeCheck == true){
			while(Final_Parent.parent != null && Final_Parent.parent.tag == "Cube"){
				Final_Parent = Final_Parent.parent;
			}
			Final_Parent.GetComponent<ForCube> ().rigid.constraints = RigidbodyConstraints.FreezeAll;
			StartCoroutine (Freeze ());
		}
	}
	IEnumerator Freeze(){
		yield return new WaitForSeconds (20f);

		Final_Parent = this.transform;
		/*while(Final_Parent.parent != null && Final_Parent.parent.tag == "Cube"){
			Final_Parent = Final_Parent.parent;
		}*/

		Final_Parent.GetComponent<ForCube> ().rigid.constraints = RigidbodyConstraints.None;
		Final_Parent.GetComponent<ForCube> ().rigid.constraints = RigidbodyConstraints.FreezeRotation;

		FreezeCheck = false;
		Freeze_Own = false;
	}
}
