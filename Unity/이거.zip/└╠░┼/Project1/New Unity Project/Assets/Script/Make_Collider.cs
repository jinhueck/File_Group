﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Make_Collider : MonoBehaviour {

	public BoxCollider[] Col = new BoxCollider[5];

	public int num;
	// Use this for initialization
	void Start () {
		
		num = this.transform.childCount;
		for (int i = 0; i < num; i++) {
			Col[i] = gameObject.AddComponent<BoxCollider>();
			Col [i].size = new Vector3 (4, 4, 4);
			Vector3 pos = this.transform.position - transform.GetChild (i).transform.position;
			Col [i].center = -pos;

		}
	}
	
	// Update is called once per frame
	void Update () {
		int current_num = this.transform.childCount;
		if (num != current_num) {
			for (int i = 0; i < num; i++) {
				Col[i] = null;
			}
			num = current_num;
			for (int i = 0; i < num; i++) {
				Col[i] = gameObject.AddComponent<BoxCollider>();
				Vector3 pos = this.transform.position - transform.GetChild (i).transform.position;
				Col [i].center = transform.GetChild(i).transform.position;
			}
		}
	}
}
