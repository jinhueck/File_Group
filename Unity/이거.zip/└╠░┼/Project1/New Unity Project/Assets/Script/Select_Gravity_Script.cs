﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Select_Gravity_Script : MonoBehaviour {

	public Transform final;
	public Transform Player;
	public bool Check_Rigid;
	Vector3 Gravity1;
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		int check = GameObject.Find ("Player").GetComponent<MoveScript>().check;

		switch (check) {
		case 0:
			Gravity1 = new Vector3(0, -1, 0);
			break;
		case 1:
			Gravity1 = new Vector3(0, 0, 1);
			break;
		case 2:
			Gravity1 = new Vector3(-1, 0 ,0);
			break;
		case 3:
			Gravity1 = new Vector3(0, 1, 0);
			break;
		case 4:
			Gravity1 = new Vector3(0, 0, -1);
			break;
		case 5:
			Gravity1 = new Vector3(1, 0, 0);
			break;
		}

		Debug.DrawRay (transform.position, Gravity1, Color.red, 50f);
		Debug.Log ("GRA: " + Gravity1);
		final = this.transform;
		if (final.transform.parent != null) {
			while (final.transform.parent != null) {
				final = final.transform.parent;
			}
		}
		RaycastHit hit;
		if (Physics.Raycast (this.transform.position, Gravity1, out hit, 50f)) {
			float distance = Vector3.Distance (this.transform.position, hit.point);
			Debug.Log ("Dis : " + distance);
			if (distance > 2.01) {
				

				if (final.GetComponent<ForCube> ().rigid.constraints == RigidbodyConstraints.FreezeAll) {
					Check_Rigid = false;
				} 
				else if (final.GetComponent<ForCube> ().rigid.constraints != RigidbodyConstraints.FreezeAll) {
					Check_Rigid = true;
				}
			} 
			else if(distance <= 2.01) {
				Check_Rigid = false;
			}
		}

	}
}
