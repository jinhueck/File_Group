﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parent_Child_Script_Own : MonoBehaviour {
	public GameObject Parent;
	public bool parent_check;
	public MoveScript ForCheckGravity;
	public float Check_Time;
	public float timer;
	public bool ch;

	// Use this for initialization
	void Start () {
		parent_check = false;
		ch = false;
	}

	// Update is called once per frame
	void Update () {
		if (parent_check == true) {
			parent_check = false;
			this.gameObject.transform.parent = Parent.gameObject.transform;
			ch = true;
		}
		if(ch == true){
			timer += Time.deltaTime;
		}
		if(timer >= Check_Time){
			timer = 0;
			ch = false;
			if (this.gameObject.transform.parent != null) {
				if (this.gameObject.transform.parent.GetComponent<ForCube> ().FreezeCheck != true) {
					this.gameObject.transform.parent.GetComponent<ForCube> ().rigid.constraints = RigidbodyConstraints.None;
					this.gameObject.transform.parent.GetComponent<ForCube> ().rigid.constraints = RigidbodyConstraints.FreezeRotation;
				}
			}
			this.gameObject.transform.parent = null;
		}

	}
	public float end(){
		float TimerForChange = timer;
		timer = 0;
		ch = false;
		if (this.gameObject.transform.parent != null) {
			if (this.gameObject.transform.parent.GetComponent<ForCube> ().FreezeCheck != true) {
				this.gameObject.transform.parent.GetComponent<ForCube> ().rigid.constraints = RigidbodyConstraints.None;
				this.gameObject.transform.parent.GetComponent<ForCube> ().rigid.constraints = RigidbodyConstraints.FreezeRotation;
			}
		}
		this.gameObject.transform.parent = null;
		return TimerForChange;
	}
	/*IEnumerator Make(){
      
   }*/
}