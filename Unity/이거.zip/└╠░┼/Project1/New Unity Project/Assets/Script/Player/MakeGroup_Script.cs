﻿using UnityEngine;
using System.Collections;

public class MakeGroup_Script : MonoBehaviour {

	public Transform Parent;
	public Transform Child;

	public bool parentcheck;
	public bool childcheck;

	public bool HaveParent_Parent;
	public bool HaveParent_Child;
	public GameObject All_Parent;

    public int layermask;

	void Start () {
		Parent = null;
		Child = null;

		parentcheck = false;
		childcheck = false;
		layermask = (-1) - (1 << LayerMask.NameToLayer("Player"));
    }

	void Update () {
		RaycastHit hit;

		if (Physics.Raycast (transform.position, transform.forward, out hit, 100f,layermask)) {
			if (Input.GetMouseButtonDown (0)) {
				Debug.Log ("YES!!!");
				Parent = hit.transform;
				parentcheck = true;
			}
			if (Input.GetMouseButtonDown (1)) {
				Child = hit.transform;
				childcheck = true;
			}
		}
		if (parentcheck == true && childcheck == true) {
			float DistanceForGroup = Vector3.Distance (Parent.transform.position, Child.transform.position);
			if (Child.tag == "Cube" && Parent.tag == "Cube" && Child.gameObject != Parent.gameObject)
            {
                if (DistanceForGroup <= 4.2f) {

					Transform Final_Child = Child.transform;
					while (Final_Child.parent != null) {
						Final_Child = Final_Child.parent;
					}
					if (Final_Child == Child)
						HaveParent_Child = false;
					else if(Final_Child != Child)
						HaveParent_Child = true;
					
					Transform Final_Parent = Parent.transform;
					while (Final_Parent.parent != null) {
						Final_Parent = Final_Parent.parent;
					}
					if (Final_Parent == Parent)
						HaveParent_Parent = false;
					else if (Final_Parent != Parent)
						HaveParent_Parent = true;

					Vector3 distance = (Child.position + Parent.position) / 2; 

					if (HaveParent_Child == true && HaveParent_Parent == true) {
						GameObject obj = Instantiate (All_Parent, distance, Quaternion.identity);
						Child.parent = obj.transform;
						Parent.parent = obj.transform;
						Destroy (Final_Child.gameObject);
						Destroy (Final_Parent.gameObject);
					} 
					else if (HaveParent_Child == true && HaveParent_Parent == false) {
						Parent.parent = Final_Child.transform;
					} 
					else if (HaveParent_Child == false && HaveParent_Parent == true) {
						Child.parent = Final_Parent.transform;
					} 
					else if (HaveParent_Child == false && HaveParent_Parent == false) {
						GameObject obj = Instantiate (All_Parent, distance, Quaternion.identity);
						Child.parent = obj.transform;
						Parent.parent = obj.transform;
					}


					//Child.GetComponent<Parent_Child_Script_Own> ().Parent = Parent.gameObject;
					//Child.GetComponent<Parent_Child_Script_Own> ().parent_check = true;
					parentcheck = false;
					childcheck = false;
                    Parent = null;
                    Child = null;
				}
                else
                {
                    Debug.Log("Too Far Between Objects");
                }
            } 
			else {
				Debug.Log ("That's not cube");
			}
			parentcheck = childcheck = false;
		}
	}
}
