﻿using UnityEngine;
using System.Collections;

public class test2 : MonoBehaviour {

	// Use this for initialization
	float x;
	public float xSpeed = 220.0f;
	public int angle;
	public float SaveAngle;
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
		x += Input.GetAxis ("Mouse X") * xSpeed * 0.02f;
		Quaternion b = Quaternion.Euler (0, x, 0);
		transform.localRotation = b;
		float SaveAngle = transform.localEulerAngles.y;

		if (SaveAngle > 45 && SaveAngle < 135) {
			//Debug.Log ("Side_1");
			angle = 1;
		} 
		else if (SaveAngle > 135 && SaveAngle < 225) {
			//Debug.Log ("Side_2");
			angle = 2;
		} 
		else if (SaveAngle > 225 && SaveAngle < 315) {
			//Debug.Log ("Side_3");
			angle = 3;
		} 
		else if ((SaveAngle < 360 && SaveAngle > 315) || (angle > 0 && angle < 45)) {
			//Debug.Log ("Side_4");
			angle = 4;
		}
		//Debug.Log ("Angle:" + angle);
	}
}
