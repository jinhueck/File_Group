﻿using UnityEngine;
using System.Collections;

public class MoveScript : MonoBehaviour {

	Rigidbody rigid;
	public float speed = 5f;
	public float jumpspeed = 150f;
	public float ladderspeed = 10f;
	public float gravity;
	public Vector3 moveDirection = Vector3.zero;
	private float jump;

	public int check = 0;
	public bool check_once = false;
	public float xSpeed = 220.0f;
	private float x;

	public bool JumpCheck = false;

	public bool OnGrounded;

	public static int NormalCheck;

	public test2 test2;

	int layerMask;

	// Use this for initialization
	void Start () {
		NormalCheck = 0;
		rigid = GetComponent<Rigidbody> ();
		test2 = GetComponentInChildren<test2> ();
		OnGrounded = true;
		layerMask = (-1) - (1<<LayerMask.NameToLayer("Parent"));
	}
	
	// Update is called once per frame
	void Update () {
		//Debug.Log (test2.gameObject.transform.right);
		//Debug.Log("velocity"+rigid.velocity);
		float v = Input.GetAxis ("Horizontal");
		float h = Input.GetAxis ("Vertical");

		RaycastHit hit;
		if(Physics.Raycast(test2.transform.position,-test2.transform.up,out hit,100f,layerMask)){
			if (hit.transform.tag == "ground" || hit.transform.tag == "Cube") {
				if (hit.distance <= 2.0001)
					OnGrounded = true;
				else
					OnGrounded = false;
			}
		}

		if (NormalCheck == 0) {
			
			Vector3 forward = test2.transform.forward;
			Vector3 right = test2.transform.right;
			Vector3 Up = test2.transform.up;

			if (OnGrounded == true)
				JumpCheck = false;

			if (Input.GetKeyDown (KeyCode.Space) && OnGrounded == true) {
				rigid.velocity = new Vector3(rigid.velocity.x/7, rigid.velocity.y/7, rigid.velocity.z/7);
				rigid.AddForce (Up * jumpspeed);
				JumpCheck = true;
			}

			if (OnGrounded == false && JumpCheck == true) {

				speed = 10f;
				//h = Mathf.Clamp (h, -0.7f, 0.7f);
				//v = Mathf.Clamp (v, -0.7f, 0.7f);

				rigid.AddForce (forward * speed * h);
				rigid.AddForce (right * speed * v);
			} 
			else if(OnGrounded == true || (OnGrounded == false && JumpCheck ==false)){
				if (MoveCube_Script.CubeCheck == false)
					speed = 15f;
				else {
					speed = 4f;
				}
				rigid.AddForce (forward * speed * h);
				rigid.AddForce (right * speed * v);
			}
			//Debug.Log (this.rigid.velocity);
		} 
		else if (NormalCheck == 1) {
			RaycastHit hitground;
			if (Physics.Raycast(test2.transform.position,-test2.transform.up,out hitground,100f)){
				if (hitground.transform.tag == "ground" && hitground.distance <= 1.5) {
					if (Input.GetKey (KeyCode.S)) {
						Vector3 Back = test2.transform.forward;
						rigid.AddForce (Back * -350);
					}
				}
					
			}
			switch (check) {
			case 0:
				rigid.velocity = new Vector3 (0, h * ladderspeed, 0);
				break;
			case 1:
				rigid.velocity = new Vector3 (0, 0, -h * ladderspeed);
				break;
			case 2:
				rigid.velocity = new Vector3 (h * ladderspeed, 0, 0);
				break;
			case 3:
				rigid.velocity = new Vector3 (0, -h * ladderspeed, 0);
				break;
			case 4:
				rigid.velocity = new Vector3 (0, 0, h * ladderspeed);
				break;
			case 5:
				rigid.velocity = new Vector3 (-h * ladderspeed, 0, 0);
				break;
			}

			if (Input.GetKey (KeyCode.Space)) {
				Vector3 forward = test2.transform.forward;
				rigid.AddForce (forward * -100f);
			}
		}
		Quaternion Gravity = Quaternion.identity;
		switch (check) {
		case 0:
			Physics.gravity = new Vector3 (0, -gravity, 0);
			Gravity.eulerAngles = new Vector3 (0, 0, 0);
			transform.rotation = Quaternion.Euler (0, 0, 0);
			break;
		case 1:
			Physics.gravity = new Vector3 (0, 0, gravity);
			Gravity.eulerAngles = new Vector3 (-90, 0, 0);
			transform.rotation = Quaternion.Euler (-90, 0, 0);
			break;
		case 2:
			Physics.gravity = new Vector3 (-gravity, 0, 0);
			Gravity.eulerAngles = new Vector3 (0, 0, -90);
			transform.rotation = Quaternion.Euler (0, 0, -90);
			break;
		case 3:
			Physics.gravity = new Vector3 (0, gravity, 0);
			Gravity.eulerAngles = new Vector3 (-180, 0, 0);
			transform.rotation = Quaternion.Euler (-180, 0, 0);
			break;
		case 4:
			Physics.gravity = new Vector3 (0, 0, -gravity);
			Gravity.eulerAngles = new Vector3 (90, 0, 0);
			transform.rotation = Quaternion.Euler (90, 0, 0);
			break;
		case 5:
			Physics.gravity = new Vector3 (gravity, 0, 0);
			Gravity.eulerAngles = new Vector3 (0, 0, 90);
			transform.rotation = Quaternion.Euler (0, 0, 90);
			break;	

		}

	}
}
