﻿using UnityEngine;
using System.Collections;

public class test : MonoBehaviour {

	Quaternion a = Quaternion.identity;
	// Use this for initialization
	void Start () {
			
	}
	public bool check = false;
	// Update is called once per frame
	void Update () {
		a.eulerAngles =	new Vector3 (-90, 0, 0);
		if (check == false) {
			
			transform.Rotate (new Vector3 (-90, 0, 0), Space.World);
			check = true;
		}
	}
}
