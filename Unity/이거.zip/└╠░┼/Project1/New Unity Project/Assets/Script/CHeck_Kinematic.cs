﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CHeck_Kinematic : MonoBehaviour {
	public Transform Final_Parent;
	public Rigidbody rigid;
	// Use this for initialization
	void Start () {
		rigid = this.GetComponent<Rigidbody> ();
	}
	
	// Update is called once per frame
	void Update () {
		Final_Parent = this.transform;
		while(Final_Parent.parent != null){
			Final_Parent = Final_Parent.parent;
		}
		if (Final_Parent == this.transform) {
			rigid.isKinematic = false;
			this.GetComponent<BoxCollider> ().isTrigger = false;
		} 
		else if (Final_Parent != this.transform) {
			rigid.isKinematic = true;
			this.GetComponent<BoxCollider> ().isTrigger = true;
		}
	}
}
