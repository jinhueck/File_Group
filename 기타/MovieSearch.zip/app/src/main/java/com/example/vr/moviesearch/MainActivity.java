package com.example.vr.moviesearch;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tts=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    tts.setLanguage(Locale.KOREAN);
                }
            }
        });
    }

    public void onSearchClick(View v) {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "말을 하세요.");
        startActivityForResult(i, 2000);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == 2000) {
            ArrayList<String> words = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

            EditText et = (EditText)findViewById(R.id.editText);
            et.append("인식단어" + words.get(0) + "\n");

            String id = DaumMovieSearch.getId(words.get(0));

            WebView webView = (WebView)findViewById(R.id.webView);
            webView.loadUrl("http://movie.daum.net/moviedb/main?movieId=" + id);

            new HttpTask(new HttpTask.OnCompletionListener() {
                public void onComplete(String result) {
                    int k = "<meta property=\"og:description\" content=".length();
                    int i = result.indexOf("<meta property=\"og:description\" content=");
                    int j = result.indexOf("..\">");
                    tts.speak(result.substring(i+k, j), TextToSpeech.QUEUE_FLUSH, null);
                }
            }).execute("http://movie.daum.net/moviedb/main?movieId=" + id);
        }
    }
}




