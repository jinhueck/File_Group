package com.example.vr.moviesearch;

/**
 * Created by vr on 2017-10-18.
 */
class DaumMovieSearch {

    static String titles[] = {"범죄도시", "남한산성", "희생부활자", "킹스맨", "블레이드러너"};
    static String ids[] = {"109512", "106472", "94864", "101819", "107541"};

    public static int getDistance(String a, String b) {
        int [] costs = new int [b.length() + 1];
        for (int j = 0; j < costs.length; j++)
            costs[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            costs[0] = i;
            int nw = i - 1;
            for (int j = 1; j <= b.length(); j++) {
                int cj = Math.min(1 + Math.min(costs[j], costs[j - 1]), a.charAt(i - 1) == b.charAt(j - 1) ? nw : nw + 1);
                nw = costs[j];
                costs[j] = cj;
            }
        }
        return costs[b.length()];
    }

    public static String getId(String title) {

        title = title.replaceAll(" ", "");

        int min = 10000000;
        int index = 0;
        for(int i = 0 ; i < titles.length; i++) {
            int d = getDistance(title, titles[i]);
            System.out.println("d = " + d);
            if ( d < min   )  {
                min = d;
                index = i;
            }
        }
        return  ids[index];
    }
}
