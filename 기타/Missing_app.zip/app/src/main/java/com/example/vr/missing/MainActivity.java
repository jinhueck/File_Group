package com.example.vr.missing;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NfcF;
import android.os.Parcelable;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    NfcAdapter mNfcAdapter; // NFC 어댑터
    PendingIntent mPendingIntent; // 수신받은 데이터가 저장된 인텐트
    IntentFilter[] mIntentFilters; // 인텐트 필터
    String[][] mNFCTechLists;
    Tag mytag;

    boolean write = false;
    String url= "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //market://details id=com.everytime.v2


        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);

        Intent intent = new Intent(this, getClass());
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        mPendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        IntentFilter iFilter = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
        try {
            iFilter.addDataType("text/plain");
            mIntentFilters = new IntentFilter[] { iFilter };
        } catch (Exception e) {
            e.printStackTrace();
        }
        mNFCTechLists = new String[][] { new String[] { NfcF.class.getName() } };


        String name = URLEncoder.encode("홍길동");
        String tel = "010-1234-5678";
        String address = URLEncoder.encode("경기도 용인시");
        String memo = URLEncoder.encode("<h1>감사합니다.</h1>");


        new HttpTask(new HttpTask.OnCompletionListener() {
            public void onComplete(String result)  {

                System.out.println(result);

                JSONObject root = null;
                try {
                    root = new JSONObject(result);
                    url = root.getString("url");
                    System.out.println("url->" + url);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }).execute("http://172.17.5.51:8080/missing.jsp?name=" +  name  + "&tel="  + tel + "&address=" + address + "&memo=" + memo );
    }


    public void onResume() {
        super.onResume();
        // 앱이 실행될때 NFC 어댑터를 활성화 한다
        if( mNfcAdapter != null )
            mNfcAdapter.enableForegroundDispatch(this, mPendingIntent, mIntentFilters, mNFCTechLists);

        // NFC 태그 스캔으로 앱이 자동 실행되었을때
        if( NfcAdapter.ACTION_NDEF_DISCOVERED.equals(getIntent().getAction()) )
            // 인텐트에 포함된 정보를 분석해서 화면에 표시
            onNewIntent(getIntent());
    }

    public void onPause() {
        super.onPause();
        // 앱이 종료될때 NFC 어댑터를 비활성화 한다
        if( mNfcAdapter != null )
            mNfcAdapter.disableForegroundDispatch(this);
    }

    public void onNewIntent(Intent intent) {

        mytag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);

        if ( write) {
            try {
                Uri uri =Uri.parse(url);
                NdefRecord recordNFC =NdefRecord.createUri(uri);
                if (recordNFC == null) System.out.println("error");

                NdefRecord[] records = {recordNFC};
                NdefMessage message = new NdefMessage(records);
                Ndef ndef = Ndef.get(mytag);
                ndef.connect();
                ndef.writeNdefMessage(message);
                ndef.close();
                write  = false;
            } catch (IOException e) {
                e.printStackTrace();
            } catch (FormatException e) {
                e.printStackTrace();
            }
        }
    }

    public void btnWriteClick(View v) {
        write = true;
    }
}
